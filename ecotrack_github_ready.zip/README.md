# EcoTrack — Carbon Footprint Tracker

EcoTrack is a React + TypeScript + Vite web application for tracking everyday activities and estimating their carbon emissions.

## Features

- Log carbon-producing activities:
  - Car travel — **0.20 kg CO₂/km**
  - Bus travel — **0.08 kg CO₂/km**
  - Electricity — **0.80 kg CO₂/kWh**
  - Vegetarian meal — **0.50 kg CO₂/meal**
  - Non-vegetarian meal — **2.00 kg CO₂/meal**
- Automatic CO₂ calculation
- Weekly target tracking
- Weekly goal/streak tracking
- Activity history
- Monthly and weekly analytics
- CSV export
- Light/dark theme
- Local browser persistence using `localStorage`
- Responsive React UI

> The emission factors above are the fixed factors currently implemented in `src/types.ts`. They are app-specific assumptions, not a universal carbon-accounting standard.

## Tech Stack

- React 19
- TypeScript
- Vite
- Tailwind CSS v4
- Lucide React
- Motion
- Node.js / npm

## Run locally

```bash
npm install
npm run dev
```

Open the local URL shown by Vite.

## Production build

```bash
npm run build
npm run preview
```

The production files are generated in `dist/`.

## GitHub Pages deployment

This repository includes a GitHub Actions workflow at:

`.github/workflows/deploy.yml`

To deploy:

1. Create a GitHub repository.
2. Push this project to the repository.
3. In GitHub, open **Settings → Pages**.
4. Set **Source** to **GitHub Actions**.
5. Push to the `main` branch.
6. GitHub Actions will build and publish the site.

Detailed instructions are in `docs/DEPLOYMENT.md`.

## Data and privacy

EcoTrack currently stores activity data and the weekly target in the user's browser via `localStorage`. No backend database is required for the current frontend implementation.

Do not place private API keys in frontend source files or commit `.env.local`.

## Project documentation

- `docs/PROJECT_DOCUMENTATION.md` — project overview, architecture, features, data model, and calculations
- `docs/DEPLOYMENT.md` — GitHub Pages deployment guide
- `docs/GITHUB_SETUP.md` — repository creation and Git commands
- `SECURITY.md` — secrets and deployment security notes

## License

Review and add the license appropriate to your project before publishing if your university/company requires one.
