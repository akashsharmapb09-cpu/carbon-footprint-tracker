# EcoTrack Project Documentation

## 1. Project title

**EcoTrack — Carbon Footprint Tracker**

## 2. Purpose

EcoTrack provides a simple frontend dashboard for recording everyday activities and estimating associated carbon dioxide emissions. It helps users understand their activity-related footprint through totals, targets, history, and visual analytics.

## 3. Main workflow

1. User opens the dashboard.
2. User records an activity.
3. User enters the quantity.
4. EcoTrack applies the fixed conversion factor for that activity.
5. The activity is stored in browser `localStorage`.
6. Dashboard metrics and charts update.
7. User can compare progress against a weekly target.
8. Activity data can be exported as CSV.

## 4. Activity calculation model

The calculation is:

**CO₂ emissions = quantity × conversion factor**

Current factors:

| Activity | Unit | Factor |
|---|---:|---:|
| Car travel | km | 0.20 kg CO₂/km |
| Bus travel | km | 0.08 kg CO₂/km |
| Electricity | kWh | 0.80 kg CO₂/kWh |
| Vegetarian meal | meal | 0.50 kg CO₂/meal |
| Non-vegetarian meal | meal | 2.00 kg CO₂/meal |

Example:

`10 km car travel × 0.20 kg CO₂/km = 2.00 kg CO₂`

## 5. Frontend architecture

### Entry point

- `src/main.tsx` — React application entry point

### Main application

- `src/App.tsx` — application state, persistence, dashboard composition

### Components

- `Navbar.tsx` — navigation/header
- `MetricsCards.tsx` — summary metrics
- `VisualAnalytics.tsx` — analytics section
- `WeeklyTargetTracker.tsx` — weekly target progress
- `WeeklyGoalStreakTracker.tsx` — goal/streak information
- `MonthlyEmissionTrendChart.tsx` — monthly trend
- `WeeklyComparisonChart.tsx` — weekly comparison
- `ActivityHistory.tsx` — logged activity history
- `ActivityLoggerModal.tsx` — activity entry UI
- `TargetModal.tsx` — weekly target configuration

### Data and utilities

- `src/types.ts` — TypeScript types and activity configuration
- `src/data/seedData.ts` — initial demonstration data
- `src/utils/calculations.ts` — emission and analytics calculations
- `src/utils/csvExport.ts` — CSV export
- `src/utils/useTheme.ts` — theme persistence/handling

## 6. Data persistence

The current application is frontend-only.

Browser storage keys include:

- `ecotrack_activities_v1`
- `ecotrack_target_v1`
- `ecotrack_last_saved_v1`

This means data is local to the browser/device. It is not automatically synchronized between users or devices.

## 7. Technology

- React
- TypeScript
- Vite
- Tailwind CSS
- Lucide React
- Motion

## 8. Future enhancements

Possible next versions could add:

- Firebase Authentication
- Cloud Firestore synchronization
- User accounts
- Multi-device history
- More emission factors
- Location-aware transport estimates
- PDF reports
- Accessibility improvements
- Unit tests
- Automated deployment previews
- Admin-managed emission factors

## 9. Important limitation

The emission factors are fixed assumptions implemented by the application. Real-world carbon emissions vary by vehicle, fuel, grid mix, travel conditions, food system, and methodology. If EcoTrack is used for academic or professional reporting, the factors should be replaced or documented according to the methodology required by the project.
