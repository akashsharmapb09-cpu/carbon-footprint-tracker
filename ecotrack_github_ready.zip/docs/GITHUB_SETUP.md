# GitHub Repository Setup

## Option A — GitHub website + terminal

Create an empty repository on GitHub, then run:

```bash
cd path/to/ecotrack

git init
git add .
git commit -m "Initial EcoTrack project"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git
git push -u origin main
```

## Option B — Existing repository

If you already have a repository and want EcoTrack inside it:

```bash
git clone https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git
cd YOUR_REPOSITORY
```

Copy the EcoTrack project files into the repository, then:

```bash
git add .
git commit -m "Add EcoTrack carbon footprint tracker"
git push
```

If the existing repository already contains another application, place EcoTrack in a dedicated folder and use a separate deployment configuration.

## Useful Git commands

Check status:

```bash
git status
```

See remote:

```bash
git remote -v
```

See commits:

```bash
git log --oneline -5
```

Push changes:

```bash
git add .
git commit -m "Describe your change"
git push
```

## Suggested repository description

> EcoTrack is a responsive React + TypeScript carbon footprint tracker that logs daily activities, calculates estimated CO₂ emissions, tracks weekly goals, and visualizes sustainability progress.

## Suggested topics

`react` `typescript` `vite` `carbon-footprint` `sustainability` `tailwindcss` `github-pages`
