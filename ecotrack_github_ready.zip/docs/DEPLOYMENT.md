# EcoTrack Deployment Guide

## Recommended deployment: GitHub Pages

EcoTrack is a Vite frontend and can be deployed as a static site with GitHub Pages.

### 1. Prerequisites

Install:

- Node.js (LTS recommended)
- Git
- A GitHub account

Check:

```bash
node --version
npm --version
git --version
```

### 2. Test the project locally

From the project folder:

```bash
npm install
npm run lint
npm run build
```

If the build succeeds, the production output will be in `dist/`.

### 3. Create the GitHub repository

On GitHub:

1. Click **New repository**.
2. Choose a repository name, for example `ecotrack`.
3. Choose Public or Private according to your needs.
4. Do not add another README if this project already contains one.
5. Create the repository.

### 4. Connect the local project to GitHub

Replace `YOUR_USERNAME` and `YOUR_REPOSITORY`:

```bash
git init
git add .
git commit -m "Initial EcoTrack project"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git
git push -u origin main
```

### 5. Enable GitHub Pages

In the repository:

**Settings → Pages → Build and deployment → Source → GitHub Actions**

The repository already contains:

`.github/workflows/deploy.yml`

The workflow installs dependencies, runs the Vite build, and publishes `dist/` to GitHub Pages.

### 6. Find the deployed website

For a normal project repository, the URL is generally:

`https://YOUR_USERNAME.github.io/YOUR_REPOSITORY/`

GitHub will show the exact Pages URL under **Settings → Pages** after deployment.

### 7. Future updates

After changing the code:

```bash
git add .
git commit -m "Update EcoTrack"
git push
```

The GitHub Actions workflow will deploy the new version automatically.

## Troubleshooting

### Blank page on GitHub Pages

Confirm that `vite.config.ts` contains:

```ts
base: './',
```

Then rebuild and push again.

### Actions build failure

Open:

**GitHub → Repository → Actions → failed workflow**

Read the first build error. Locally, run:

```bash
npm install
npm run lint
npm run build
```

### Site deploys but old content appears

Wait for the Pages deployment to finish, then hard-refresh the browser.

### Custom domain

If you later use a custom domain, review the Vite `base` setting and GitHub Pages custom-domain configuration rather than keeping a repository-relative path blindly.
