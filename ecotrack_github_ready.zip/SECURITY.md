# Security Notes

## Secrets

Never commit:

- `.env.local`
- API keys
- access tokens
- passwords
- service-account JSON files
- private certificates

The repository `.gitignore` already ignores `.env*` except `.env.example`.

## Gemini API key

The existing `.env.example` references `GEMINI_API_KEY`. A Gemini API key should not be hard-coded into browser JavaScript or committed to GitHub.

If AI functionality is added later, use a server-side endpoint or another secure architecture where the secret is not exposed to the client.

## Firebase configuration

`firebase-applet-config.json` contains Firebase web-app configuration. Web Firebase configuration values can be visible in frontend applications, but that does **not** make Firebase security rules optional.

If Firebase is enabled:

- Configure Firebase Authentication correctly.
- Use restrictive Firestore/Storage security rules.
- Restrict API usage where appropriate.
- Never commit Firebase service-account private keys.

If the Firebase configuration is not used by the current app, it can be removed from the repository to reduce unnecessary files.

## Before publishing

Run:

```bash
git status
```

and confirm no secret files are staged.

If a secret has already been committed, rotate/revoke it and remove it from Git history as appropriate; simply deleting the file in a later commit does not make the old secret safe.
