import { CarbonActivity } from '../types';
import { calculateEmissions, getCalendarWeekRange } from '../utils/calculations';

/**
 * Generates sample seed activities distributed across the active week and past days
 * so the initial view is immediately rich and interactive.
 */
export function generateSeedActivities(): CarbonActivity[] {
  const now = new Date();
  const { start: weekStart } = getCalendarWeekRange(now);

  // Helper to get an ISO date offset from current week's Monday
  const getWeekOffsetDate = (daysFromMonday: number, hours: number, minutes: number): string => {
    const d = new Date(weekStart);
    d.setDate(weekStart.getDate() + daysFromMonday);
    d.setHours(hours, minutes, 0, 0);
    // If the computed date is in the future relative to now, pull it back
    if (d > now) {
      const fallback = new Date(now);
      fallback.setHours(Math.max(8, hours), minutes, 0, 0);
      return fallback.toISOString();
    }
    return d.toISOString();
  };

  const rawSeed = [
    {
      id: 'act-1',
      type: 'car' as const,
      category: 'travel' as const,
      quantity: 18,
      note: 'Commute to downtown office',
      timestamp: getWeekOffsetDate(0, 8, 30), // Monday morning
    },
    {
      id: 'act-2',
      type: 'veg_meal' as const,
      category: 'food' as const,
      quantity: 1,
      note: 'Mediterranean grain salad for lunch',
      timestamp: getWeekOffsetDate(0, 12, 45),
    },
    {
      id: 'act-3',
      type: 'electricity' as const,
      category: 'energy' as const,
      quantity: 9.5,
      note: 'Home lighting, laptop & appliances',
      timestamp: getWeekOffsetDate(0, 20, 15),
    },
    {
      id: 'act-4',
      type: 'bus' as const,
      category: 'travel' as const,
      quantity: 14,
      note: 'Bus line 42 to co-working space',
      timestamp: getWeekOffsetDate(1, 9, 10), // Tuesday
    },
    {
      id: 'act-5',
      type: 'non_veg_meal' as const,
      category: 'food' as const,
      quantity: 1,
      note: 'Grilled chicken bowl with dinner guests',
      timestamp: getWeekOffsetDate(1, 19, 30),
    },
    {
      id: 'act-6',
      type: 'electricity' as const,
      category: 'energy' as const,
      quantity: 7.2,
      note: 'EV trickle charge & heat pump',
      timestamp: getWeekOffsetDate(2, 18, 0),
    },
    {
      id: 'act-7',
      type: 'veg_meal' as const,
      category: 'food' as const,
      quantity: 2,
      note: 'Oatmeal breakfast and lentil wrap',
      timestamp: getWeekOffsetDate(2, 13, 0),
    },
    {
      id: 'act-8',
      type: 'car' as const,
      category: 'travel' as const,
      quantity: 12,
      note: 'Weekend farmers market grocery run',
      timestamp: new Date(weekStart.getTime() - 3 * 86400000 + 10 * 3600000).toISOString(),
    },
    {
      id: 'act-9',
      type: 'electricity' as const,
      category: 'energy' as const,
      quantity: 14,
      note: 'Laundry & dishwasher cycle',
      timestamp: new Date(weekStart.getTime() - 4 * 86400000 + 18 * 3600000).toISOString(),
    },
    {
      id: 'act-10',
      type: 'car' as const,
      category: 'travel' as const,
      quantity: 25,
      note: 'Highway commute to client meeting',
      timestamp: new Date(weekStart.getTime() - 7 * 86400000 + 9 * 3600000).toISOString(),
    },
    {
      id: 'act-11',
      type: 'non_veg_meal' as const,
      category: 'food' as const,
      quantity: 2,
      note: 'Steakhouse dinner with team',
      timestamp: new Date(weekStart.getTime() - 5 * 86400000 + 19 * 3600000).toISOString(),
    },
    {
      id: 'act-12',
      type: 'bus' as const,
      category: 'travel' as const,
      quantity: 16,
      note: 'Public transit cross-town route',
      timestamp: new Date(weekStart.getTime() - 1 * 86400000 + 14 * 3600000).toISOString(),
    },
    {
      id: 'act-13',
      type: 'car' as const,
      category: 'travel' as const,
      quantity: 20,
      note: 'Regional park weekend excursion',
      timestamp: new Date(weekStart.getTime() - 11 * 86400000 + 11 * 3600000).toISOString(),
    },
    {
      id: 'act-14',
      type: 'electricity' as const,
      category: 'energy' as const,
      quantity: 12,
      note: 'Normal weekday home power consumption',
      timestamp: new Date(weekStart.getTime() - 10 * 86400000 + 17 * 3600000).toISOString(),
    },
    {
      id: 'act-15',
      type: 'veg_meal' as const,
      category: 'food' as const,
      quantity: 3,
      note: 'Plant-forward meals throughout the day',
      timestamp: new Date(weekStart.getTime() - 9 * 86400000 + 13 * 3600000).toISOString(),
    },
    {
      id: 'act-16',
      type: 'bus' as const,
      category: 'travel' as const,
      quantity: 25,
      note: 'Commuter express bus to city center',
      timestamp: new Date(weekStart.getTime() - 13 * 86400000 + 8 * 3600000).toISOString(),
    },
    {
      id: 'act-17',
      type: 'car' as const,
      category: 'travel' as const,
      quantity: 30,
      note: 'Family trip to botanical gardens',
      timestamp: new Date(weekStart.getTime() - 17 * 86400000 + 10 * 3600000).toISOString(),
    },
    {
      id: 'act-18',
      type: 'electricity' as const,
      category: 'energy' as const,
      quantity: 15,
      note: 'Mid-week energy usage & electronics',
      timestamp: new Date(weekStart.getTime() - 19 * 86400000 + 19 * 3600000).toISOString(),
    },
    {
      id: 'act-19',
      type: 'non_veg_meal' as const,
      category: 'food' as const,
      quantity: 1,
      note: 'Family dinner special occasion',
      timestamp: new Date(weekStart.getTime() - 18 * 86400000 + 20 * 3600000).toISOString(),
    },
    // Historical monthly activities across the current year (Jan - Aug) for annual trend analysis
    {
      id: 'act-hist-jan-1',
      type: 'electricity' as const,
      category: 'energy' as const,
      quantity: 38,
      note: 'Winter heating & appliances',
      timestamp: new Date(now.getFullYear(), 0, 15, 19, 0).toISOString(),
    },
    {
      id: 'act-hist-jan-2',
      type: 'car' as const,
      category: 'travel' as const,
      quantity: 65,
      note: 'Winter driving & suburban errands',
      timestamp: new Date(now.getFullYear(), 0, 22, 10, 30).toISOString(),
    },
    {
      id: 'act-hist-jan-3',
      type: 'non_veg_meal' as const,
      category: 'food' as const,
      quantity: 4,
      note: 'Comfort meals during cold wave',
      timestamp: new Date(now.getFullYear(), 0, 28, 20, 0).toISOString(),
    },
    {
      id: 'act-hist-feb-1',
      type: 'bus' as const,
      category: 'travel' as const,
      quantity: 50,
      note: 'Transit challenge week commute',
      timestamp: new Date(now.getFullYear(), 1, 10, 8, 30).toISOString(),
    },
    {
      id: 'act-hist-feb-2',
      type: 'electricity' as const,
      category: 'energy' as const,
      quantity: 26,
      note: 'Mid-winter apartment lighting & heat',
      timestamp: new Date(now.getFullYear(), 1, 18, 18, 0).toISOString(),
    },
    {
      id: 'act-hist-feb-3',
      type: 'veg_meal' as const,
      category: 'food' as const,
      quantity: 6,
      note: 'Plant-forward food challenge',
      timestamp: new Date(now.getFullYear(), 1, 24, 13, 15).toISOString(),
    },
    {
      id: 'act-hist-mar-1',
      type: 'car' as const,
      category: 'travel' as const,
      quantity: 45,
      note: 'Spring break day trip',
      timestamp: new Date(now.getFullYear(), 2, 14, 11, 0).toISOString(),
    },
    {
      id: 'act-hist-mar-2',
      type: 'electricity' as const,
      category: 'energy' as const,
      quantity: 22,
      note: 'Mild spring home power use',
      timestamp: new Date(now.getFullYear(), 2, 21, 20, 30).toISOString(),
    },
    {
      id: 'act-hist-apr-1',
      type: 'bus' as const,
      category: 'travel' as const,
      quantity: 40,
      note: 'Earth Month daily transit rides',
      timestamp: new Date(now.getFullYear(), 3, 12, 9, 0).toISOString(),
    },
    {
      id: 'act-hist-apr-2',
      type: 'veg_meal' as const,
      category: 'food' as const,
      quantity: 8,
      note: 'Earth Month vegetarian meal pledge',
      timestamp: new Date(now.getFullYear(), 3, 22, 12, 30).toISOString(),
    },
    {
      id: 'act-hist-apr-3',
      type: 'electricity' as const,
      category: 'energy' as const,
      quantity: 18,
      note: 'Moderate spring energy consumption',
      timestamp: new Date(now.getFullYear(), 3, 27, 19, 0).toISOString(),
    },
    {
      id: 'act-hist-may-1',
      type: 'car' as const,
      category: 'travel' as const,
      quantity: 55,
      note: 'Memorial Day weekend mountain trail drive',
      timestamp: new Date(now.getFullYear(), 4, 18, 10, 0).toISOString(),
    },
    {
      id: 'act-hist-may-2',
      type: 'non_veg_meal' as const,
      category: 'food' as const,
      quantity: 3,
      note: 'Outdoor BBQ gathering',
      timestamp: new Date(now.getFullYear(), 4, 25, 17, 30).toISOString(),
    },
    {
      id: 'act-hist-jun-1',
      type: 'car' as const,
      category: 'travel' as const,
      quantity: 75,
      note: 'Summer road trip to coastal national park',
      timestamp: new Date(now.getFullYear(), 5, 12, 8, 0).toISOString(),
    },
    {
      id: 'act-hist-jun-2',
      type: 'electricity' as const,
      category: 'energy' as const,
      quantity: 32,
      note: 'Early summer cooling & fan usage',
      timestamp: new Date(now.getFullYear(), 5, 26, 21, 0).toISOString(),
    },
    {
      id: 'act-hist-jul-1',
      type: 'car' as const,
      category: 'travel' as const,
      quantity: 90,
      note: 'Mid-summer lake vacation highway driving',
      timestamp: new Date(now.getFullYear(), 6, 8, 9, 30).toISOString(),
    },
    {
      id: 'act-hist-jul-2',
      type: 'electricity' as const,
      category: 'energy' as const,
      quantity: 40,
      note: 'Peak heat AC cooling cycles',
      timestamp: new Date(now.getFullYear(), 6, 20, 16, 0).toISOString(),
    },
    {
      id: 'act-hist-jul-3',
      type: 'non_veg_meal' as const,
      category: 'food' as const,
      quantity: 4,
      note: 'Summer cookouts with friends',
      timestamp: new Date(now.getFullYear(), 6, 27, 19, 30).toISOString(),
    },
    {
      id: 'act-hist-aug-1',
      type: 'car' as const,
      category: 'travel' as const,
      quantity: 60,
      note: 'Regional camping and day trips',
      timestamp: new Date(now.getFullYear(), 7, 10, 11, 0).toISOString(),
    },
    {
      id: 'act-hist-aug-2',
      type: 'electricity' as const,
      category: 'energy' as const,
      quantity: 34,
      note: 'Late summer air conditioning',
      timestamp: new Date(now.getFullYear(), 7, 22, 18, 0).toISOString(),
    },
    {
      id: 'act-hist-aug-3',
      type: 'bus' as const,
      category: 'travel' as const,
      quantity: 35,
      note: 'Back-to-work public transit trips',
      timestamp: new Date(now.getFullYear(), 7, 29, 8, 45).toISOString(),
    },
  ];

  return rawSeed.map((item) => ({
    ...item,
    emissionsKg: calculateEmissions(item.type, item.quantity),
  }));
}
