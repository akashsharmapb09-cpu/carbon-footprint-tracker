import { CarbonActivity, ACTIVITY_CONFIGS } from '../types';

/**
 * Escapes a field for CSV format conforming to RFC 4180.
 * If the value contains quotes, commas, or line breaks, it is wrapped in double quotes
 * and internal double quotes are escaped by doubling them ("").
 */
function escapeCSVField(value: unknown): string {
  if (value === null || value === undefined) {
    return '';
  }
  const str = String(value);
  if (str.includes('"') || str.includes(',') || str.includes('\n') || str.includes('\r')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

/**
 * Converts a list of CarbonActivity records into an RFC 4180 compliant CSV string.
 * Includes UTF-8 Byte Order Mark (BOM) for seamless opening in Microsoft Excel and Google Sheets.
 */
export function generateActivitiesCSV(activities: CarbonActivity[]): string {
  const headers = [
    'Activity ID',
    'ISO Timestamp',
    'Date',
    'Time',
    'Category',
    'Activity Name',
    'Quantity',
    'Unit',
    'Carbon Emissions (kg CO2)',
    'Notes',
  ];

  const rows = activities.map((act) => {
    const config = ACTIVITY_CONFIGS[act.type];
    const dateObj = new Date(act.timestamp);
    const dateStr = !isNaN(dateObj.getTime())
      ? dateObj.toISOString().split('T')[0]
      : '';
    const timeStr = !isNaN(dateObj.getTime())
      ? dateObj.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      : '';

    const categoryLabel =
      act.category === 'travel'
        ? 'Travel & Transport'
        : act.category === 'energy'
        ? 'Home Energy'
        : 'Food & Diet';

    const activityName = config ? config.label : act.type;
    const unit = config ? config.unit : (act.type === 'car' || act.type === 'bus' ? 'km' : act.type === 'electricity' ? 'kWh' : 'meals');

    return [
      escapeCSVField(act.id),
      escapeCSVField(act.timestamp),
      escapeCSVField(dateStr),
      escapeCSVField(timeStr),
      escapeCSVField(categoryLabel),
      escapeCSVField(activityName),
      escapeCSVField(act.quantity),
      escapeCSVField(unit),
      escapeCSVField(Number(act.emissionsKg || 0).toFixed(2)),
      escapeCSVField(act.note || ''),
    ].join(',');
  });

  // Calculate total summary for archive convenience
  const totalEmissions = activities.reduce((sum, a) => sum + (a.emissionsKg || 0), 0);
  const summaryRow = [
    'TOTAL',
    '',
    '',
    '',
    '',
    `${activities.length} activities`,
    '',
    '',
    escapeCSVField(totalEmissions.toFixed(2)),
    'Archived from EcoTrack Carbon Tracker',
  ].join(',');

  // Prefix with UTF-8 BOM (\uFEFF) to guarantee correct character encoding in Excel
  return '\uFEFF' + [headers.join(','), ...rows, summaryRow].join('\r\n');
}

/**
 * Triggers the browser file download for the generated CSV archive.
 */
export function downloadActivitiesCSV(
  activities: CarbonActivity[],
  filenamePrefix = 'ecotrack-activity-history'
): boolean {
  if (!activities || activities.length === 0) {
    return false;
  }

  try {
    const csvContent = generateActivitiesCSV(activities);
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);

    const now = new Date();
    const datePart = now.toISOString().split('T')[0];
    const timePart = now.toTimeString().split(' ')[0].replace(/:/g, '-');
    const filename = `${filenamePrefix}-${datePart}_${timePart}.csv`;

    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', filename);
    link.style.display = 'none';

    document.body.appendChild(link);
    link.click();

    setTimeout(() => {
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }, 200);

    return true;
  } catch (err) {
    console.error('Failed to download CSV:', err);
    return false;
  }
}
