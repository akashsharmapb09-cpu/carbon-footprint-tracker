import React, { useState } from 'react';
import {
  TrendingDown,
  TrendingUp,
  Minus,
  Calendar,
  Layers,
  BarChart2,
  Car,
  Zap,
  Salad,
  Info,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';
import { CarbonActivity, ActivityCategory } from '../types';
import { getWeekComparison, WeekComparisonMetrics } from '../utils/calculations';

interface WeeklyComparisonChartProps {
  activities: CarbonActivity[];
  weeklyTarget: number;
}

type ComparisonViewMode = 'totals' | 'daily' | 'categories';

export const WeeklyComparisonChart: React.FC<WeeklyComparisonChartProps> = ({
  activities,
  weeklyTarget,
}) => {
  const [viewMode, setViewMode] = useState<ComparisonViewMode>('totals');
  const [hoveredDay, setHoveredDay] = useState<string | null>(null);

  const comparison: WeekComparisonMetrics = getWeekComparison(activities);
  const {
    currentWeekTotalKg,
    previousWeekTotalKg,
    differenceKg,
    percentageChange,
    isReduction,
    currentWeekRangeLabel,
    previousWeekRangeLabel,
    categoryComparison,
    dayComparison,
  } = comparison;

  // Max value for scale normalization in totals view
  const maxTotalKg = Math.max(weeklyTarget, currentWeekTotalKg, previousWeekTotalKg, 10);

  // Max value for daily comparison view
  const maxDailyKg = Math.max(
    5,
    ...dayComparison.map((d) => Math.max(d.currentKg, d.previousKg))
  );

  // Max value for category comparison view
  const maxCategoryKg = Math.max(
    5,
    ...categoryComparison.map((c) => Math.max(c.currentKg, c.previousKg))
  );

  const categoryIcons: Record<ActivityCategory, React.ReactNode> = {
    travel: <Car className="w-3.5 h-3.5" />,
    energy: <Zap className="w-3.5 h-3.5" />,
    food: <Salad className="w-3.5 h-3.5" />,
  };

  return (
    <div
      id="weekly-comparison-panel"
      className="p-6 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700/80 shadow-xs"
    >
      {/* Header with Title, Delta Badge, and View Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-100 dark:border-slate-700/70">
        <div className="flex items-start sm:items-center gap-3">
          <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 shrink-0">
            <BarChart2 className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-display font-bold text-base sm:text-lg text-slate-900 dark:text-white">
                Week-over-Week Emissions Comparison
              </h3>

              {/* Status Badge */}
              {previousWeekTotalKg === 0 && currentWeekTotalKg === 0 ? (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-600 dark:bg-slate-700 dark:text-slate-300">
                  <Minus className="w-3.5 h-3.5" /> No activity recorded
                </span>
              ) : isReduction ? (
                <span
                  id="weekly-delta-badge"
                  className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800"
                >
                  <TrendingDown className="w-3.5 h-3.5" />
                  {percentageChange !== null
                    ? `${Math.abs(percentageChange)}% lower`
                    : `${Math.abs(differenceKg).toFixed(1)} kg lower`}
                  ({Math.abs(differenceKg).toFixed(1)} kg CO₂ reduction)
                </span>
              ) : differenceKg > 0 ? (
                <span
                  id="weekly-delta-badge"
                  className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300 border border-amber-200 dark:border-amber-800"
                >
                  <TrendingUp className="w-3.5 h-3.5" />
                  {percentageChange !== null
                    ? `+${percentageChange}% higher`
                    : `+${differenceKg.toFixed(1)} kg higher`}
                  (+{differenceKg.toFixed(1)} kg CO₂)
                </span>
              ) : (
                <span
                  id="weekly-delta-badge"
                  className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 dark:bg-slate-700 dark:text-slate-300"
                >
                  <Minus className="w-3.5 h-3.5" /> Equal to previous week
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Comparing current calendar week ({currentWeekRangeLabel}) against previous week ({previousWeekRangeLabel})
            </p>
          </div>
        </div>

        {/* View Mode Toggle Controls */}
        <div
          id="weekly-comparison-view-tabs"
          className="inline-flex p-1 bg-slate-100 dark:bg-slate-900 rounded-xl self-start sm:self-auto"
          role="tablist"
          aria-label="Comparison chart view mode"
        >
          <button
            id="tab-view-totals"
            type="button"
            onClick={() => setViewMode('totals')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer ${
              viewMode === 'totals'
                ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs font-semibold'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
            role="tab"
            aria-selected={viewMode === 'totals'}
          >
            Total Comparison
          </button>
          <button
            id="tab-view-daily"
            type="button"
            onClick={() => setViewMode('daily')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer ${
              viewMode === 'daily'
                ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs font-semibold'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
            role="tab"
            aria-selected={viewMode === 'daily'}
          >
            Day-by-Day
          </button>
          <button
            id="tab-view-categories"
            type="button"
            onClick={() => setViewMode('categories')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all cursor-pointer ${
              viewMode === 'categories'
                ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs font-semibold'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
            role="tab"
            aria-selected={viewMode === 'categories'}
          >
            By Category
          </button>
        </div>
      </div>

      {/* View 1: Totals Comparison (Primary Visual Bar Comparison) */}
      {viewMode === 'totals' && (
        <div id="comparison-totals-view" className="py-6">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
            {/* Main Bar Chart Container */}
            <div className="md:col-span-8 flex flex-col justify-end">
              <div className="h-64 flex items-end justify-around gap-6 sm:gap-12 px-4 sm:px-12 pt-8 pb-3 border-b border-slate-100 dark:border-slate-700/80 relative">
                {/* Target Benchmark Line */}
                <div
                  className="absolute left-0 right-0 border-b border-dashed border-emerald-400/80 z-0 pointer-events-none"
                  style={{
                    bottom: `${Math.min(94, Math.max(12, (weeklyTarget / maxTotalKg) * 100))}%`,
                  }}
                >
                  <span className="absolute right-2 -top-4 text-[10px] font-semibold text-emerald-700 dark:text-emerald-300 bg-white/95 dark:bg-slate-800/95 px-1.5 py-0.5 rounded border border-emerald-200 dark:border-emerald-800/60 shadow-2xs">
                    Target Budget: {weeklyTarget} kg CO₂
                  </span>
                </div>

                {/* Column 1: Previous Week Bar */}
                <div className="flex-1 flex flex-col items-center h-full justify-end max-w-[140px] relative z-10">
                  <div className="mb-2 text-center">
                    <span className="block text-xs font-bold text-slate-600 dark:text-slate-300 font-display">
                      {previousWeekTotalKg.toFixed(2)} kg
                    </span>
                    <span className="text-[10px] text-slate-400">Total CO₂</span>
                  </div>

                  {/* Visual Bar */}
                  <div className="w-full h-full flex items-end justify-center">
                    <div
                      id="previous-week-bar"
                      className="w-full max-w-[84px] rounded-t-xl bg-slate-300 hover:bg-slate-400 dark:bg-slate-600 dark:hover:bg-slate-500 transition-all duration-300 relative group cursor-pointer shadow-sm flex flex-col justify-end overflow-hidden"
                      style={{
                        height: `${Math.max(8, Math.round((previousWeekTotalKg / maxTotalKg) * 100))}%`,
                      }}
                    >
                      {/* Tooltip */}
                      <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute -top-10 left-1/2 -translate-x-1/2 bg-slate-900 text-white dark:bg-white dark:text-slate-900 text-[11px] font-medium px-2.5 py-1 rounded shadow-lg pointer-events-none whitespace-nowrap z-30">
                        Previous Week: {previousWeekTotalKg.toFixed(2)} kg CO₂
                      </div>
                    </div>
                  </div>

                  {/* Label */}
                  <div className="mt-3 text-center">
                    <span className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                      Previous Week
                    </span>
                    <span className="block text-[11px] text-slate-400">
                      {previousWeekRangeLabel}
                    </span>
                  </div>
                </div>

                {/* Delta Callout Bridge in Center */}
                <div className="hidden sm:flex flex-col items-center justify-center self-center px-2 py-3 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-700/60 text-center z-10">
                  <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                    Net Delta
                  </span>
                  <div className="flex items-center gap-1 my-1">
                    {isReduction ? (
                      <TrendingDown className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                    ) : differenceKg > 0 ? (
                      <TrendingUp className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                    ) : (
                      <Minus className="w-4 h-4 text-slate-400" />
                    )}
                    <span
                      className={`text-sm font-bold font-display ${
                        isReduction
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : differenceKg > 0
                          ? 'text-amber-600 dark:text-amber-400'
                          : 'text-slate-500'
                      }`}
                    >
                      {differenceKg > 0 ? `+${differenceKg.toFixed(1)}` : `${differenceKg.toFixed(1)}`} kg
                    </span>
                  </div>
                  {percentageChange !== null && (
                    <span
                      className={`text-[10px] font-semibold px-1.5 py-0.5 rounded ${
                        isReduction
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : differenceKg > 0
                          ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                          : 'bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {percentageChange > 0 ? `+${percentageChange}%` : `${percentageChange}%`}
                    </span>
                  )}
                </div>

                {/* Column 2: Current Week Bar */}
                <div className="flex-1 flex flex-col items-center h-full justify-end max-w-[140px] relative z-10">
                  <div className="mb-2 text-center">
                    <span className="block text-xs font-bold text-emerald-600 dark:text-emerald-400 font-display">
                      {currentWeekTotalKg.toFixed(2)} kg
                    </span>
                    <span className="text-[10px] text-slate-400">Total CO₂</span>
                  </div>

                  {/* Visual Bar */}
                  <div className="w-full h-full flex items-end justify-center">
                    <div
                      id="current-week-bar"
                      className="w-full max-w-[84px] rounded-t-xl bg-emerald-500 hover:bg-emerald-600 dark:bg-emerald-400 dark:hover:bg-emerald-500 transition-all duration-300 relative group cursor-pointer shadow-md shadow-emerald-500/20 ring-2 ring-emerald-300/80 dark:ring-emerald-600/60 flex flex-col justify-end overflow-hidden"
                      style={{
                        height: `${Math.max(8, Math.round((currentWeekTotalKg / maxTotalKg) * 100))}%`,
                      }}
                    >
                      {/* Tooltip */}
                      <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute -top-10 left-1/2 -translate-x-1/2 bg-slate-900 text-white dark:bg-white dark:text-slate-900 text-[11px] font-medium px-2.5 py-1 rounded shadow-lg pointer-events-none whitespace-nowrap z-30">
                        Current Week: {currentWeekTotalKg.toFixed(2)} kg CO₂
                      </div>
                    </div>
                  </div>

                  {/* Label */}
                  <div className="mt-3 text-center">
                    <div className="inline-flex items-center gap-1">
                      <span className="block text-xs font-bold text-slate-900 dark:text-white">
                        This Week
                      </span>
                      <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                    </div>
                    <span className="block text-[11px] text-slate-400">
                      {currentWeekRangeLabel}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Side: Key Variance Insights & Breakdown */}
            <div className="md:col-span-4 space-y-4">
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-700/60 space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-500 dark:text-slate-400 font-medium">
                    Previous Week Total
                  </span>
                  <span className="font-bold text-slate-800 dark:text-slate-200 font-display">
                    {previousWeekTotalKg.toFixed(2)} kg CO₂
                  </span>
                </div>

                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-500 dark:text-slate-400 font-medium">
                    Current Week Total
                  </span>
                  <span className="font-bold text-emerald-600 dark:text-emerald-400 font-display">
                    {currentWeekTotalKg.toFixed(2)} kg CO₂
                  </span>
                </div>

                <div className="pt-2 border-t border-slate-200/70 dark:border-slate-700/70 flex items-center justify-between text-xs">
                  <span className="text-slate-600 dark:text-slate-300 font-semibold">
                    Net Variance
                  </span>
                  <span
                    className={`font-display font-bold ${
                      isReduction
                        ? 'text-emerald-600 dark:text-emerald-400'
                        : differenceKg > 0
                        ? 'text-amber-600 dark:text-amber-400'
                        : 'text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    {differenceKg > 0 ? `+${differenceKg.toFixed(2)}` : `${differenceKg.toFixed(2)}`} kg CO₂
                  </span>
                </div>
              </div>

              {/* Climate Insight Message */}
              <div
                className={`p-3.5 rounded-xl border flex items-start gap-2.5 text-xs ${
                  isReduction
                    ? 'bg-emerald-50/70 dark:bg-emerald-950/30 border-emerald-200/80 dark:border-emerald-900/50 text-emerald-900 dark:text-emerald-200'
                    : differenceKg > 0
                    ? 'bg-amber-50/70 dark:bg-amber-950/30 border-amber-200/80 dark:border-amber-900/50 text-amber-900 dark:text-amber-200'
                    : 'bg-slate-50 dark:bg-slate-900/50 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                {isReduction ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
                ) : differenceKg > 0 ? (
                  <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                ) : (
                  <Info className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
                )}
                <p className="leading-relaxed">
                  {isReduction
                    ? `Great progress! Your weekly emissions dropped by ${Math.abs(differenceKg).toFixed(1)} kg CO₂ compared to last week.`
                    : differenceKg > 0
                    ? `Emissions are currently ${differenceKg.toFixed(1)} kg higher than last week. Consider substituting travel or meat meals before the week concludes.`
                    : 'Your emissions are matching last week. Log your activities regularly to keep tracking your environmental impact.'}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* View 2: Day-by-Day Comparative Bar Chart */}
      {viewMode === 'daily' && (
        <div id="comparison-daily-view" className="py-5">
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
            Compare daily emission levels side-by-side (Last week vs. This week) to uncover which days contributed most to changes.
          </p>

          <div className="h-56 flex items-end justify-between gap-2 sm:gap-4 px-2 sm:px-6 pt-6 pb-2 border-b border-slate-100 dark:border-slate-700/80 relative">
            {dayComparison.map((day) => {
              const isHovered = hoveredDay === day.dayName;
              const prevHeight = maxDailyKg > 0 ? Math.round((day.previousKg / maxDailyKg) * 100) : 0;
              const currHeight = maxDailyKg > 0 ? Math.round((day.currentKg / maxDailyKg) * 100) : 0;

              return (
                <div
                  key={day.dayName}
                  onMouseEnter={() => setHoveredDay(day.dayName)}
                  onMouseLeave={() => setHoveredDay(null)}
                  className="flex-1 flex flex-col items-center h-full justify-end group relative cursor-pointer"
                >
                  {/* Tooltip */}
                  {isHovered && (
                    <div className="absolute -top-14 bg-slate-900 text-white dark:bg-white dark:text-slate-900 text-[11px] font-medium px-2.5 py-1.5 rounded shadow-lg pointer-events-none whitespace-nowrap z-30">
                      <span className="block font-bold">{day.dayName} Comparison:</span>
                      <span>This Week: {day.currentKg.toFixed(2)} kg</span>
                      <span className="text-slate-300 dark:text-slate-600"> | </span>
                      <span>Last Week: {day.previousKg.toFixed(2)} kg</span>
                    </div>
                  )}

                  {/* Paired Bars */}
                  <div className="w-full flex items-end justify-center gap-1 sm:gap-1.5 h-full">
                    {/* Previous Week Day Bar */}
                    <div
                      className="w-1/2 max-w-[18px] rounded-t-sm bg-slate-300 dark:bg-slate-600 transition-all duration-300 hover:bg-slate-400"
                      style={{ height: `${Math.max(4, prevHeight)}%` }}
                    />
                    {/* Current Week Day Bar */}
                    <div
                      className={`w-1/2 max-w-[18px] rounded-t-sm transition-all duration-300 ${
                        day.currentKg > day.previousKg && day.previousKg > 0
                          ? 'bg-amber-400 dark:bg-amber-500'
                          : 'bg-emerald-500 dark:bg-emerald-400'
                      }`}
                      style={{ height: `${Math.max(4, currHeight)}%` }}
                    />
                  </div>

                  {/* Day Label */}
                  <span className="mt-2 text-xs font-semibold text-slate-700 dark:text-slate-300">
                    {day.dayName}
                  </span>
                </div>
              );
            })}
          </div>

          {/* Legend */}
          <div className="mt-4 flex items-center justify-between flex-wrap gap-3 text-xs text-slate-500 dark:text-slate-400">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded bg-slate-300 dark:bg-slate-600"></span>
                <span>Previous Week</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded bg-emerald-500 dark:bg-emerald-400"></span>
                <span>This Week (Lower or Initial)</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded bg-amber-400 dark:bg-amber-500"></span>
                <span>This Week (Higher than Last Week)</span>
              </span>
            </div>
            <span className="text-[11px] text-slate-400">Hover any day for exact kg metrics</span>
          </div>
        </div>
      )}

      {/* View 3: By Category Comparison */}
      {viewMode === 'categories' && (
        <div id="comparison-categories-view" className="py-5 space-y-5">
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Breakdown of emissions shifts across travel, energy, and diet categories between the two weeks.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {categoryComparison.map((cat) => {
              const isCatReduction = cat.diffKg < 0;
              const hasNoDiff = cat.diffKg === 0;

              return (
                <div
                  key={cat.category}
                  className="p-4 rounded-xl border border-slate-200 dark:border-slate-700/80 bg-slate-50/60 dark:bg-slate-800/60 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <span
                          className="p-1.5 rounded-lg text-white"
                          style={{ backgroundColor: cat.color }}
                        >
                          {categoryIcons[cat.category]}
                        </span>
                        <span className="font-bold text-sm text-slate-800 dark:text-slate-200">
                          {cat.label}
                        </span>
                      </div>
                      <span
                        className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                          isCatReduction
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : hasNoDiff
                            ? 'bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-300'
                            : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                        }`}
                      >
                        {cat.diffKg > 0 ? `+${cat.diffKg.toFixed(1)}` : `${cat.diffKg.toFixed(1)}`} kg
                      </span>
                    </div>

                    {/* Comparative Bars for this category */}
                    <div className="space-y-2 mt-4 text-xs">
                      <div>
                        <div className="flex justify-between text-[11px] text-slate-500 dark:text-slate-400 mb-1">
                          <span>Previous Week</span>
                          <span className="font-semibold text-slate-700 dark:text-slate-300">
                            {cat.previousKg.toFixed(2)} kg
                          </span>
                        </div>
                        <div className="w-full h-2 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                          <div
                            className="h-full rounded-full bg-slate-400 dark:bg-slate-500"
                            style={{
                              width: `${maxCategoryKg > 0 ? (cat.previousKg / maxCategoryKg) * 100 : 0}%`,
                            }}
                          />
                        </div>
                      </div>

                      <div>
                        <div className="flex justify-between text-[11px] text-slate-500 dark:text-slate-400 mb-1">
                          <span>This Week</span>
                          <span className="font-bold text-slate-900 dark:text-white">
                            {cat.currentKg.toFixed(2)} kg
                          </span>
                        </div>
                        <div className="w-full h-2 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                          <div
                            className="h-full rounded-full transition-all duration-300"
                            style={{
                              width: `${maxCategoryKg > 0 ? (cat.currentKg / maxCategoryKg) * 100 : 0}%`,
                              backgroundColor: cat.color,
                            }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-200/60 dark:border-slate-700/60 text-[11px] text-slate-500 dark:text-slate-400">
                    {isCatReduction
                      ? `Lowered by ${Math.abs(cat.diffKg).toFixed(1)} kg CO₂ this week.`
                      : cat.diffKg > 0
                      ? `Increased by ${cat.diffKg.toFixed(1)} kg CO₂ this week.`
                      : `Identical emissions to last week.`}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
