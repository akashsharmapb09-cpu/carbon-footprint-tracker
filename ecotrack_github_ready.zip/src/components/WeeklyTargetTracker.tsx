import React from 'react';
import {
  Target,
  AlertTriangle,
  AlertOctagon,
  CheckCircle2,
  Edit3,
  Calendar,
  Sparkles,
  Flame,
} from 'lucide-react';
import { getCalendarWeekRange } from '../utils/calculations';

interface WeeklyTargetTrackerProps {
  weeklyTarget: number;
  currentWeekTotal: number;
  currentStreak?: number;
  onOpenTargetModal: () => void;
}

export const WeeklyTargetTracker: React.FC<WeeklyTargetTrackerProps> = ({
  weeklyTarget,
  currentWeekTotal,
  currentStreak = 0,
  onOpenTargetModal,
}) => {
  const safeTarget = Math.max(1, weeklyTarget);
  const percentage = Math.round((currentWeekTotal / safeTarget) * 100);
  const clampedProgressWidth = Math.min(100, Math.max(0, percentage));

  const { start: weekStart, end: weekEnd } = getCalendarWeekRange(new Date());
  const weekStartStr = weekStart.toLocaleDateString([], { month: 'short', day: 'numeric' });
  const weekEndStr = weekEnd.toLocaleDateString([], { month: 'short', day: 'numeric' });

  // State determination
  const isExceeded = percentage >= 100;
  const isWarning = percentage >= 80 && percentage < 100;
  const isNormal = percentage < 80;

  const diffKg = Math.abs(Math.round((safeTarget - currentWeekTotal) * 100) / 100);

  return (
    <div className="w-full">
      {/* Exceeded Banner (if >= 100%) */}
      {isExceeded && (
        <div
          id="budget-exceeded-alert-banner"
          className="mb-4 p-4 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 text-rose-900 dark:text-rose-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs animate-in fade-in duration-200"
        >
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-lg bg-rose-100 dark:bg-rose-900/60 text-rose-600 dark:text-rose-300 shrink-0">
              <AlertOctagon className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-semibold text-sm text-rose-900 dark:text-rose-100">
                Weekly Carbon Budget Exceeded
              </h4>
              <p className="text-xs text-rose-700 dark:text-rose-300 mt-0.5">
                You have reached <strong>{percentage}%</strong> of your target and exceeded your budget by{' '}
                <strong>{diffKg.toFixed(2)} kg CO₂</strong> for this calendar week.
              </p>
            </div>
          </div>
          <button
            id="adjust-target-exceeded-button"
            onClick={onOpenTargetModal}
            className="self-end sm:self-auto px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold shrink-0 cursor-pointer transition shadow-xs"
          >
            Adjust Target
          </button>
        </div>
      )}

      {/* Main Weekly Target Card */}
      <div
        id="weekly-target-card"
        className={`p-5 sm:p-6 rounded-2xl border transition-all duration-200 ${
          isExceeded
            ? 'bg-white dark:bg-slate-800/90 border-rose-300 dark:border-rose-900/60 shadow-sm'
            : isWarning
            ? 'bg-white dark:bg-slate-800/90 border-amber-300 dark:border-amber-900/60 shadow-sm'
            : 'bg-white dark:bg-slate-800/90 border-slate-200 dark:border-slate-700/80 shadow-xs'
        }`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-2.5">
            <div
              className={`p-2.5 rounded-xl ${
                isExceeded
                  ? 'bg-rose-100 text-rose-700 dark:bg-rose-950/80 dark:text-rose-400'
                  : isWarning
                  ? 'bg-amber-100 text-amber-700 dark:bg-amber-950/80 dark:text-amber-400'
                  : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/80 dark:text-emerald-400'
              }`}
            >
              <Target className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-display font-bold text-base sm:text-lg text-slate-900 dark:text-white">
                  Weekly Carbon Budget
                </h3>
                <span
                  className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                    isExceeded
                      ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300 border border-rose-200 dark:border-rose-800'
                      : isWarning
                      ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 border border-amber-200 dark:border-amber-800'
                      : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
                  }`}
                >
                  {isExceeded && <AlertOctagon className="w-3 h-3" />}
                  {isWarning && <AlertTriangle className="w-3 h-3" />}
                  {isNormal && <CheckCircle2 className="w-3 h-3" />}
                  {isExceeded ? 'Exceeded' : isWarning ? 'Caution Warning' : 'On Track'}
                </span>
                {currentStreak > 0 && (
                  <a
                    id="weekly-target-streak-badge"
                    href="#weekly-goal-streak-card"
                    onClick={(e) => {
                      e.preventDefault();
                      document.getElementById('weekly-goal-streak-card')?.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-200 border border-amber-200 dark:border-amber-800 hover:bg-amber-200 transition shadow-2xs cursor-pointer"
                    title="View Weekly Goal Streak & Badges"
                  >
                    <Flame className="w-3 h-3 fill-amber-500 text-amber-500" />
                    <span>{currentStreak}w Streak</span>
                  </a>
                )}
              </div>
              <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                <Calendar className="w-3.5 h-3.5" />
                <span>
                  Active calendar week: {weekStartStr} – {weekEndStr} (Mon–Sun)
                </span>
              </div>
            </div>
          </div>

          {/* Target Edit Button */}
          <button
            id="edit-weekly-target-button"
            onClick={onOpenTargetModal}
            className="self-start sm:self-auto flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 hover:bg-slate-200 dark:bg-slate-700/70 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-600 cursor-pointer transition"
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>Target: {weeklyTarget} kg CO₂</span>
          </button>
        </div>

        {/* Big numbers & Breakdown */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-4">
          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900/50 border border-slate-100 dark:border-slate-800/80">
            <span className="block text-[11px] font-medium text-slate-500 dark:text-slate-400">Emissions Logged</span>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span className="font-display font-bold text-xl sm:text-2xl text-slate-900 dark:text-white">
                {currentWeekTotal.toFixed(2)}
              </span>
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">kg CO₂</span>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900/50 border border-slate-100 dark:border-slate-800/80">
            <span className="block text-[11px] font-medium text-slate-500 dark:text-slate-400">
              {isExceeded ? 'Budget Exceeded By' : 'Remaining Budget'}
            </span>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span
                className={`font-display font-bold text-xl sm:text-2xl ${
                  isExceeded
                    ? 'text-rose-600 dark:text-rose-400'
                    : isWarning
                    ? 'text-amber-600 dark:text-amber-400'
                    : 'text-emerald-600 dark:text-emerald-400'
                }`}
              >
                {diffKg.toFixed(2)}
              </span>
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">kg CO₂</span>
            </div>
          </div>

          <div className="col-span-2 sm:col-span-1 p-3 rounded-xl bg-slate-50 dark:bg-slate-900/50 border border-slate-100 dark:border-slate-800/80">
            <span className="block text-[11px] font-medium text-slate-500 dark:text-slate-400">Quota Consumed</span>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span
                className={`font-display font-bold text-xl sm:text-2xl ${
                  isExceeded
                    ? 'text-rose-600 dark:text-rose-400'
                    : isWarning
                    ? 'text-amber-600 dark:text-amber-400'
                    : 'text-emerald-600 dark:text-emerald-400'
                }`}
              >
                {percentage}%
              </span>
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">of {weeklyTarget} kg limit</span>
            </div>
          </div>
        </div>

        {/* Real-Time Progress Bar */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>0 kg</span>
            <span className="font-medium text-slate-700 dark:text-slate-300">
              {currentWeekTotal.toFixed(1)} / {weeklyTarget} kg
            </span>
            <span>{weeklyTarget} kg limit</span>
          </div>

          <div className="relative w-full h-3.5 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden p-0.5">
            <div
              id="weekly-progress-fill"
              className={`h-full rounded-full transition-all duration-500 ${
                isExceeded
                  ? 'bg-rose-500'
                  : isWarning
                  ? 'bg-amber-500'
                  : 'bg-emerald-500'
              }`}
              style={{ width: `${clampedProgressWidth}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 pt-0.5">
            <span className="flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-emerald-500" />
              {isExceeded
                ? 'Tip: Choose bus transit or vegetarian meals to curb further impact.'
                : isWarning
                ? 'Watch out: Approaching weekly limit with 80%+ consumed.'
                : 'Pacing great: Keeping well within sustainable targets!'}
            </span>
            <span>{isExceeded ? '100%+ used' : `${percentage}% used`}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
