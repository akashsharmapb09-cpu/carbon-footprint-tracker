import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Filter,
  Search,
  Calendar,
  Trash2,
  Car,
  Bus,
  Zap,
  Salad,
  Beef,
  ArrowUpDown,
  Plus,
  Clock,
  RotateCcw,
  X,
  Download,
  FileSpreadsheet,
  Check,
  ChevronDown,
} from 'lucide-react';
import {
  ACTIVITY_CONFIGS,
  ActivityCategory,
  CarbonActivity,
  DateRangePreset,
} from '../types';
import { filterActivities, formatActivityDate } from '../utils/calculations';
import { downloadActivitiesCSV } from '../utils/csvExport';

interface ActivityHistoryProps {
  activities: CarbonActivity[];
  onDeleteActivity: (id: string) => void;
  onOpenLogModal: () => void;
}

export const ActivityHistory: React.FC<ActivityHistoryProps> = ({
  activities,
  onDeleteActivity,
  onOpenLogModal,
}) => {
  const [categoryFilter, setCategoryFilter] = useState<'all' | ActivityCategory>('all');
  const [dateFilter, setDateFilter] = useState<DateRangePreset>('all');
  const [customStart, setCustomStart] = useState<string>('');
  const [customEnd, setCustomEnd] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('desc');

  // Filter activities
  const filtered = filterActivities(
    activities,
    categoryFilter,
    dateFilter,
    customStart,
    customEnd,
    searchQuery
  );

  // Sort activities
  const sorted = [...filtered].sort((a, b) => {
    const timeA = new Date(a.timestamp).getTime();
    const timeB = new Date(b.timestamp).getTime();
    return sortOrder === 'desc' ? timeB - timeA : timeA - timeB;
  });

  const totalFilteredEmissions = filtered.reduce((sum, item) => sum + (item.emissionsKg || 0), 0);

  // Category icons mapping
  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'car':
        return <Car className="w-4 h-4 text-sky-600 dark:text-sky-400" />;
      case 'bus':
        return <Bus className="w-4 h-4 text-teal-600 dark:text-teal-400" />;
      case 'electricity':
        return <Zap className="w-4 h-4 text-amber-600 dark:text-amber-400" />;
      case 'veg_meal':
        return <Salad className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />;
      case 'non_veg_meal':
        return <Beef className="w-4 h-4 text-rose-600 dark:text-rose-400" />;
      default:
        return <Calendar className="w-4 h-4" />;
    }
  };

  const [isExportMenuOpen, setIsExportMenuOpen] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);
  const exportMenuRef = useRef<HTMLDivElement>(null);

  // Close export menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (exportMenuRef.current && !exportMenuRef.current.contains(event.target as Node)) {
        setIsExportMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const hasActiveFilters =
    categoryFilter !== 'all' ||
    dateFilter !== 'all' ||
    searchQuery.trim().length > 0 ||
    Boolean(customStart) ||
    Boolean(customEnd);

  const resetFilters = () => {
    setCategoryFilter('all');
    setDateFilter('all');
    setCustomStart('');
    setCustomEnd('');
    setSearchQuery('');
  };

  const handleDownloadCSV = (mode: 'filtered' | 'all' = 'filtered') => {
    const listToDownload = mode === 'all' ? activities : sorted;
    if (listToDownload.length === 0) return;
    const isFiltered = mode === 'filtered' && hasActiveFilters && sorted.length !== activities.length;
    const prefix = isFiltered ? 'ecotrack-filtered-history' : 'ecotrack-activity-history';
    const success = downloadActivitiesCSV(listToDownload, prefix);
    if (success) {
      setDownloadSuccess(
        isFiltered
          ? `Archived ${listToDownload.length} filtered entries to CSV`
          : `Archived complete history (${listToDownload.length} entries) to CSV`
      );
      setTimeout(() => {
        setDownloadSuccess(null);
      }, 3500);
    }
    setIsExportMenuOpen(false);
  };

  return (
    <div
      id="activity-history-section"
      className="p-6 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700/80 shadow-xs"
    >
      {/* Title & Actions Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
        <div>
          <h3 className="font-display font-bold text-lg text-slate-900 dark:text-white">
            Activity Log & History
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Chronological records of daily carbon-emitting actions
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Download CSV Export Button with optional menu if filtered */}
          <div className="relative" ref={exportMenuRef}>
            {hasActiveFilters && sorted.length !== activities.length ? (
              <div className="inline-flex rounded-lg shadow-2xs border border-slate-200/90 dark:border-slate-700 bg-white dark:bg-slate-800 overflow-hidden">
                <button
                  id="download-filtered-csv-button"
                  onClick={() => handleDownloadCSV('filtered')}
                  disabled={sorted.length === 0}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed border-r border-slate-200 dark:border-slate-700"
                  title="Download filtered activities as CSV archive"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                  <span>Download CSV ({sorted.length})</span>
                </button>
                <button
                  id="toggle-export-menu-button"
                  onClick={() => setIsExportMenuOpen(!isExportMenuOpen)}
                  className="px-2 py-1.5 text-slate-500 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 transition cursor-pointer"
                  title="More CSV export options"
                >
                  <ChevronDown className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button
                id="download-activity-csv-button"
                onClick={() => handleDownloadCSV('all')}
                disabled={activities.length === 0}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200/90 dark:border-slate-700 transition cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed shadow-2xs"
                title="Download complete activity history as CSV archive"
              >
                <Download className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                <span>Download CSV</span>
              </button>
            )}

            {/* Dropdown Menu when split button is clicked */}
            {isExportMenuOpen && (
              <div
                id="export-csv-dropdown-menu"
                className="absolute right-0 mt-1.5 w-64 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xl p-1.5 z-40 space-y-1 text-xs"
              >
                <div className="px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                  Export Options
                </div>
                <button
                  id="export-filtered-option-btn"
                  onClick={() => handleDownloadCSV('filtered')}
                  disabled={sorted.length === 0}
                  className="w-full text-left px-2.5 py-2 rounded-lg flex items-center justify-between text-slate-700 dark:text-slate-200 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 hover:text-emerald-700 dark:hover:text-emerald-300 transition cursor-pointer disabled:opacity-50"
                >
                  <span className="flex items-center gap-2">
                    <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                    <span className="font-medium">Filtered Results</span>
                  </span>
                  <span className="text-[11px] text-slate-400 font-semibold">{sorted.length} items</span>
                </button>
                <button
                  id="export-all-option-btn"
                  onClick={() => handleDownloadCSV('all')}
                  disabled={activities.length === 0}
                  className="w-full text-left px-2.5 py-2 rounded-lg flex items-center justify-between text-slate-700 dark:text-slate-200 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 hover:text-emerald-700 dark:hover:text-emerald-300 transition cursor-pointer disabled:opacity-50"
                >
                  <span className="flex items-center gap-2">
                    <Download className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                    <span className="font-medium">Complete Archive</span>
                  </span>
                  <span className="text-[11px] text-slate-400 font-semibold">{activities.length} items</span>
                </button>
              </div>
            )}
          </div>

          {/* Sort order toggle */}
          <button
            id="toggle-sort-button"
            onClick={() => setSortOrder(sortOrder === 'desc' ? 'asc' : 'desc')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-300 transition cursor-pointer"
            title="Toggle chronological sorting"
          >
            <ArrowUpDown className="w-3.5 h-3.5" />
            <span>{sortOrder === 'desc' ? 'Newest First' : 'Oldest First'}</span>
          </button>

          {/* Quick Add Button */}
          <button
            id="log-activity-from-history-button"
            onClick={onOpenLogModal}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white transition cursor-pointer shadow-xs"
          >
            <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>New Activity</span>
          </button>
        </div>
      </div>

      {/* Download Success Banner */}
      <AnimatePresence>
        {downloadSuccess && (
          <motion.div
            id="csv-download-success-banner"
            initial={{ opacity: 0, y: -6, height: 0 }}
            animate={{ opacity: 1, y: 0, height: 'auto' }}
            exit={{ opacity: 0, y: -6, height: 0 }}
            transition={{ duration: 0.2 }}
            className="flex items-center justify-between gap-2 px-3.5 py-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/70 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs font-semibold mb-4 shadow-2xs"
          >
            <div className="flex items-center gap-2">
              <span className="p-1 rounded-md bg-emerald-100 dark:bg-emerald-900/80 text-emerald-700 dark:text-emerald-300">
                <Check className="w-3.5 h-3.5 stroke-[3]" />
              </span>
              <span>{downloadSuccess}</span>
            </div>
            <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-normal">
              Saved to your downloads folder
            </span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Filter Controls Bar */}
      <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 space-y-3 mb-5">
        {/* Row 1: Search and Preset Ranges */}
        <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
          {/* Search bar */}
          <div className="relative flex-1 max-w-md">
            <label htmlFor="activity-search-input" className="sr-only">
              Search activities by name or notes
            </label>
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
            <input
              id="activity-search-input"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by activity name (e.g. Car, Electricity) or notes..."
              className="w-full pl-9 pr-8 py-2 rounded-lg text-xs bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all shadow-2xs"
            />
            {searchQuery && (
              <button
                id="clear-search-button"
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 p-0.5 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition cursor-pointer"
                title="Clear search query"
                aria-label="Clear search query"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Date Range Selector */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0">
            <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 shrink-0 mr-1 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5" />
              Range:
            </span>
            {(
              [
                { id: 'all', label: 'All Time' },
                { id: 'today', label: 'Today' },
                { id: 'this_week', label: 'This Week' },
                { id: 'this_month', label: 'This Month' },
                { id: 'custom', label: 'Custom' },
              ] as { id: DateRangePreset; label: string }[]
            ).map((preset) => (
              <button
                key={preset.id}
                id={`filter-date-${preset.id}`}
                onClick={() => setDateFilter(preset.id)}
                className={`px-2.5 py-1 rounded-md text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                  dateFilter === preset.id
                    ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 shadow-xs'
                    : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:border-slate-300'
                }`}
              >
                {preset.label}
              </button>
            ))}
          </div>
        </div>

        {/* Active Search Query Chip */}
        {searchQuery.trim() && (
          <div className="flex items-center gap-2 pt-0.5">
            <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
              Filtered by:
            </span>
            <span
              id="active-search-badge"
              className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-800 dark:bg-emerald-950/70 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800/80"
            >
              <Search className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
              <span>&ldquo;{searchQuery.trim()}&rdquo;</span>
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="hover:opacity-75 cursor-pointer ml-0.5"
                title="Remove search filter"
                aria-label="Remove search filter"
              >
                <X className="w-3 h-3" />
              </button>
            </span>
            <span className="text-[11px] text-slate-400">
              ({sorted.length} {sorted.length === 1 ? 'match' : 'matches'})
            </span>
          </div>
        )}

        {/* Row 2: Category Filter Buttons */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-slate-200/60 dark:border-slate-800">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 mr-1 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" />
              Category:
            </span>
            {[
              { id: 'all', label: 'All Categories' },
              { id: 'travel', label: 'Travel' },
              { id: 'energy', label: 'Energy' },
              { id: 'food', label: 'Food' },
            ].map((cat) => (
              <button
                key={cat.id}
                id={`filter-cat-${cat.id}`}
                onClick={() => setCategoryFilter(cat.id as 'all' | ActivityCategory)}
                className={`px-2.5 py-1 rounded-md text-xs font-semibold transition cursor-pointer ${
                  categoryFilter === cat.id
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:border-slate-300'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Active Filter Metrics, Quick CSV Download & Reset button */}
          <div className="flex flex-wrap items-center gap-2.5">
            <span className="text-xs text-slate-500 dark:text-slate-400">
              Showing <strong>{sorted.length}</strong> of {activities.length} entries (
              <strong className="text-slate-800 dark:text-slate-200">
                {totalFilteredEmissions.toFixed(2)} kg CO₂
              </strong>
              )
            </span>
            {sorted.length > 0 && (
              <button
                id="inline-download-csv-btn"
                onClick={() => handleDownloadCSV('filtered')}
                className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 hover:text-emerald-700 dark:hover:text-emerald-300 hover:underline cursor-pointer ml-1"
                title="Download this view as CSV"
              >
                <FileSpreadsheet className="w-3.5 h-3.5" />
                <span>Export View</span>
              </button>
            )}
            {hasActiveFilters && (
              <button
                id="reset-filters-button"
                onClick={resetFilters}
                className="flex items-center gap-1 text-[11px] text-slate-500 hover:text-rose-600 dark:text-slate-400 dark:hover:text-rose-400 font-semibold hover:underline cursor-pointer ml-1"
              >
                <RotateCcw className="w-3 h-3" />
                Reset
              </button>
            )}
          </div>
        </div>

        {/* Custom Date Range Inputs (if 'custom' selected) */}
        {dateFilter === 'custom' && (
          <div className="pt-2 border-t border-slate-200 dark:border-slate-700/80 flex flex-wrap items-center gap-3 animate-in fade-in duration-150">
            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-500 dark:text-slate-400 font-medium">From:</span>
              <input
                id="custom-start-date"
                type="date"
                value={customStart}
                onChange={(e) => setCustomStart(e.target.value)}
                className="px-2.5 py-1 rounded-md bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 text-slate-900 dark:text-white text-xs"
              />
            </div>
            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-500 dark:text-slate-400 font-medium">To:</span>
              <input
                id="custom-end-date"
                type="date"
                value={customEnd}
                onChange={(e) => setCustomEnd(e.target.value)}
                className="px-2.5 py-1 rounded-md bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 text-slate-900 dark:text-white text-xs"
              />
            </div>
            {(customStart || customEnd) && (
              <button
                id="clear-custom-date-range-button"
                type="button"
                onClick={() => {
                  setCustomStart('');
                  setCustomEnd('');
                }}
                className="text-[11px] text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
              >
                Clear range
              </button>
            )}
          </div>
        )}
      </div>

      {/* Activity Records: Responsive Data Table & Feed */}
      {sorted.length > 0 ? (
        <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-700/80">
          <table className="w-full text-left border-collapse" id="activities-table">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-900/60 border-b border-slate-200 dark:border-slate-700 text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                <th className="py-3 px-4">Activity & Category</th>
                <th className="py-3 px-4">Quantity</th>
                <th className="py-3 px-4">Rate & Formula</th>
                <th className="py-3 px-4">CO₂ Emissions</th>
                <th className="py-3 px-4">Logged Date</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
              <AnimatePresence initial={false}>
                {sorted.map((item, index) => {
                  const config = ACTIVITY_CONFIGS[item.type];
                  const dateInfo = formatActivityDate(item.timestamp);
                  const emissionFactor = config?.conversionFactor || 0;

                  return (
                    <motion.tr
                      key={item.id}
                      id={`activity-row-${item.id}`}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -6, transition: { duration: 0.15 } }}
                      transition={{
                        duration: 0.24,
                        delay: Math.min(index * 0.025, 0.2),
                        ease: [0.25, 1, 0.5, 1],
                      }}
                      className="hover:bg-slate-50/80 dark:hover:bg-slate-800/50 transition-colors group"
                    >
                      {/* Activity & Note */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <div className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200/70 dark:border-slate-700 shrink-0">
                            {getActivityIcon(item.type)}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-semibold text-slate-900 dark:text-white">
                                {config?.label || item.type}
                              </span>
                              <span
                                className={`px-1.5 py-0.5 rounded text-[10px] font-semibold uppercase tracking-wider ${
                                  item.category === 'travel'
                                    ? 'bg-sky-100 text-sky-700 dark:bg-sky-950/60 dark:text-sky-300'
                                    : item.category === 'energy'
                                    ? 'bg-amber-100 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300'
                                    : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300'
                                }`}
                              >
                                {config?.categoryLabel || item.category}
                              </span>
                            </div>
                            {item.note && (
                              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 max-w-xs truncate">
                                {item.note}
                              </p>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Quantity */}
                      <td className="py-3.5 px-4">
                        <span className="font-medium text-slate-800 dark:text-slate-200">
                          {item.quantity}{' '}
                          <span className="text-slate-400 font-normal">
                            {config?.unit || ''}
                          </span>
                        </span>
                      </td>

                      {/* Conversion formula */}
                      <td className="py-3.5 px-4 text-slate-500 dark:text-slate-400 font-mono text-[11px]">
                        {emissionFactor} kg / {config?.unit?.replace(/s$/, '')}
                      </td>

                      {/* Calculated Emission */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-baseline gap-1">
                          <span className="font-display font-bold text-sm text-slate-900 dark:text-white">
                            {item.emissionsKg.toFixed(2)}
                          </span>
                          <span className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400">
                            kg CO₂
                          </span>
                        </div>
                      </td>

                      {/* Date */}
                      <td className="py-3.5 px-4 text-slate-600 dark:text-slate-300 whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5 text-slate-400" />
                          <span>{dateInfo.relative}</span>
                        </div>
                      </td>

                      {/* Action Item: Delete */}
                      <td className="py-3.5 px-4 text-right">
                        <button
                          id={`delete-activity-${item.id}`}
                          onClick={() => onDeleteActivity(item.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 dark:hover:text-rose-400 transition cursor-pointer"
                          title="Delete this entry and recalculate totals"
                          aria-label={`Delete ${config?.label || 'activity'}`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </motion.tr>
                  );
                })}
              </AnimatePresence>
            </tbody>
          </table>
        </div>
      ) : (
        /* Empty State */
        <motion.div
          id="activity-history-empty"
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.22, ease: 'easeOut' }}
          className="p-10 rounded-xl border border-dashed border-slate-200 dark:border-slate-700 text-center flex flex-col items-center justify-center bg-slate-50/50 dark:bg-slate-900/30"
        >
          <div className="w-12 h-12 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-400 mb-3">
            {searchQuery.trim() ? (
              <Search className="w-5 h-5 text-slate-400" />
            ) : (
              <Filter className="w-5 h-5" />
            )}
          </div>
          <h4 className="font-display font-bold text-base text-slate-800 dark:text-slate-200">
            {searchQuery.trim()
              ? `No activities match "${searchQuery.trim()}"`
              : 'No activities match your filters'}
          </h4>
          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mt-1 mb-4">
            {searchQuery.trim()
              ? 'Check for typos or try searching for another activity name (e.g. Car, Electricity, Bus) or note description.'
              : hasActiveFilters
              ? 'Try widening your date range, clearing the category filter, or clearing your search term.'
              : 'Start logging your daily commutes, home energy, or meals to see your carbon analytics.'}
          </p>
          <div className="flex items-center gap-2">
            {searchQuery.trim() ? (
              <button
                id="empty-clear-search-button"
                onClick={() => setSearchQuery('')}
                className="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition cursor-pointer flex items-center gap-1.5"
              >
                <X className="w-3.5 h-3.5" />
                Clear Search Query
              </button>
            ) : hasActiveFilters ? (
              <button
                id="empty-reset-filters-button"
                type="button"
                onClick={resetFilters}
                className="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 hover:bg-slate-300 dark:hover:bg-slate-600 transition cursor-pointer"
              >
                Reset Filters
              </button>
            ) : (
              <button
                id="empty-log-first-activity-button"
                type="button"
                onClick={onOpenLogModal}
                className="px-4 py-2 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm transition cursor-pointer flex items-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
                Log Your First Activity
              </button>
            )}
          </div>
        </motion.div>
      )}
    </div>
  );
};
