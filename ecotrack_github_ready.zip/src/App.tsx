/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useMemo, useCallback } from 'react';
import { Plus, Leaf, Heart } from 'lucide-react';
import { CarbonActivity } from './types';
import { generateSeedActivities } from './data/seedData';
import { computeDashboardMetrics, computeWeeklyStreakSummary } from './utils/calculations';
import { useTheme } from './utils/useTheme';
import { Navbar } from './components/Navbar';
import { WeeklyTargetTracker } from './components/WeeklyTargetTracker';
import { WeeklyGoalStreakTracker } from './components/WeeklyGoalStreakTracker';
import { MetricsCards } from './components/MetricsCards';
import { VisualAnalytics } from './components/VisualAnalytics';
import { ActivityHistory } from './components/ActivityHistory';
import { ActivityLoggerModal } from './components/ActivityLoggerModal';
import { TargetModal } from './components/TargetModal';

const STORAGE_KEY_ACTIVITIES = 'ecotrack_activities_v1';
const STORAGE_KEY_TARGET = 'ecotrack_target_v1';
const STORAGE_KEY_LAST_SAVED = 'ecotrack_last_saved_v1';

export default function App() {
  // Theme state managed with persistence, multi-tab sync, and Tailwind v4 dark mode
  const {
    preference: themePreference,
    isDark,
    setThemePreference,
    toggleTheme,
  } = useTheme();

  // Weekly target limit state (default 50 kg CO2/week)
  const [weeklyTarget, setWeeklyTarget] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_TARGET);
      if (saved) {
        const val = parseFloat(saved);
        if (!isNaN(val) && val > 0) return val;
      }
    } catch (e) {
      console.error('Failed to read target from localStorage', e);
    }
    return 50;
  });

  // Activities collection state
  const [activities, setActivities] = useState<CarbonActivity[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_ACTIVITIES);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.error('Failed to read activities from localStorage', e);
    }
    // Default seed dataset so new users see rich visualizations immediately
    return generateSeedActivities();
  });

  // Last saved to localStorage timestamp tracking
  const [lastSaved, setLastSaved] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_LAST_SAVED);
      if (saved) {
        const parsed = parseInt(saved, 10);
        if (!isNaN(parsed) && parsed > 0) return parsed;
      }
    } catch (e) {
      console.error('Failed to read lastSaved from localStorage', e);
    }
    return Date.now();
  });

  const [isSyncing, setIsSyncing] = useState<boolean>(false);

  // Sync activities to localStorage whenever modified
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_ACTIVITIES, JSON.stringify(activities));
      const now = Date.now();
      localStorage.setItem(STORAGE_KEY_LAST_SAVED, String(now));
      setLastSaved(now);
    } catch (e) {
      console.error('Failed to persist activities to localStorage', e);
    }
  }, [activities]);

  // Sync target to localStorage whenever modified
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_TARGET, String(weeklyTarget));
      const now = Date.now();
      localStorage.setItem(STORAGE_KEY_LAST_SAVED, String(now));
      setLastSaved(now);
    } catch (e) {
      console.error('Failed to persist target to localStorage', e);
    }
  }, [weeklyTarget]);

  // Manual Sync/Save handler for user peace of mind
  const handleManualSync = useCallback(() => {
    setIsSyncing(true);
    try {
      localStorage.setItem(STORAGE_KEY_ACTIVITIES, JSON.stringify(activities));
      localStorage.setItem(STORAGE_KEY_TARGET, String(weeklyTarget));
      const now = Date.now();
      localStorage.setItem(STORAGE_KEY_LAST_SAVED, String(now));
      setLastSaved(now);

      // Brief tactile delay for smooth UX transition
      setTimeout(() => {
        setIsSyncing(false);
      }, 450);
    } catch (err) {
      console.error('Failed manual sync to localStorage', err);
      setIsSyncing(false);
    }
  }, [activities, weeklyTarget]);

  // Modal open states
  const [isLogModalOpen, setIsLogModalOpen] = useState(false);
  const [isTargetModalOpen, setIsTargetModalOpen] = useState(false);

  // Recalculate dashboard aggregates whenever activities or weeklyTarget changes
  const metrics = useMemo(() => {
    return computeDashboardMetrics(activities, weeklyTarget);
  }, [activities, weeklyTarget]);

  // Recalculate weekly goal streak and badge awards
  const streakSummary = useMemo(() => {
    return computeWeeklyStreakSummary(activities, weeklyTarget);
  }, [activities, weeklyTarget]);

  // Handler: Add activity
  const handleAddActivity = (newActData: Omit<CarbonActivity, 'id'>) => {
    const newActivity: CarbonActivity = {
      ...newActData,
      id: `act-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    };
    setActivities((prev) => [newActivity, ...prev]);
  };

  // Handler: Delete activity
  const handleDeleteActivity = (id: string) => {
    setActivities((prev) => prev.filter((item) => item.id !== id));
  };

  // Handler: Save custom target
  const handleSaveTarget = (newTarget: number) => {
    setWeeklyTarget(newTarget);
  };

  // Handler: Reset to demo dataset
  const handleResetDemo = () => {
    setActivities(generateSeedActivities());
  };

  // Handler: Clear all activities
  const handleClearAll = () => {
    setActivities([]);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors duration-200">
      {/* Sticky Header Navigation */}
      <Navbar
        onOpenLogModal={() => setIsLogModalOpen(true)}
        onOpenTargetModal={() => setIsTargetModalOpen(true)}
        onResetDemo={handleResetDemo}
        onClearAll={handleClearAll}
        activities={activities}
        weeklyTarget={weeklyTarget}
        currentWeekTotal={metrics.currentWeekKg}
        currentStreak={streakSummary.currentStreak}
        isDark={isDark}
        themePreference={themePreference}
        onToggleTheme={toggleTheme}
        onSelectTheme={setThemePreference}
        lastSaved={lastSaved}
        isSyncing={isSyncing}
        onManualSync={handleManualSync}
      />

      {/* Main Content Dashboard */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-6 sm:space-y-8">
        {/* Section 1: Weekly Target Tracker & Alert System */}
        <section aria-label="Weekly Target Progress">
          <WeeklyTargetTracker
            weeklyTarget={weeklyTarget}
            currentWeekTotal={metrics.currentWeekKg}
            currentStreak={streakSummary.currentStreak}
            onOpenTargetModal={() => setIsTargetModalOpen(true)}
          />
        </section>

        {/* Section 2: Weekly Goal Streak Tracker & Badges */}
        <section aria-label="Weekly Goal Streak and Badges">
          <WeeklyGoalStreakTracker
            activities={activities}
            weeklyTarget={weeklyTarget}
          />
        </section>

        {/* Section 3: Key Metrics Summary Cards */}
        <section aria-label="Key Emission Metrics">
          <MetricsCards
            metrics={metrics}
            totalActivitiesCount={activities.length}
          />
        </section>

        {/* Section 4: Visual Analytics (Category Donut & 7-Day Trend) */}
        <section aria-label="Visual Analytics and Breakdown">
          <VisualAnalytics
            metrics={metrics}
            activities={activities}
            weeklyTarget={weeklyTarget}
          />
        </section>

        {/* Section 5: Activity History & Filtering */}
        <section aria-label="Activity Records and History">
          <ActivityHistory
            activities={activities}
            onDeleteActivity={handleDeleteActivity}
            onOpenLogModal={() => setIsLogModalOpen(true)}
          />
        </section>
      </main>

      {/* Floating Action Button for Mobile */}
      <div className="sm:hidden fixed bottom-5 right-5 z-40">
        <button
          id="mobile-floating-log-button"
          onClick={() => setIsLogModalOpen(true)}
          className="w-14 h-14 rounded-full bg-emerald-600 active:bg-emerald-700 text-white shadow-lg shadow-emerald-600/40 flex items-center justify-center cursor-pointer transition-transform active:scale-95"
          aria-label="Log activity"
        >
          <Plus className="w-6 h-6 stroke-[3]" />
        </button>
      </div>

      {/* Activity Logger Modal */}
      <ActivityLoggerModal
        isOpen={isLogModalOpen}
        onClose={() => setIsLogModalOpen(false)}
        onAddActivity={handleAddActivity}
      />

      {/* Target Settings Modal */}
      <TargetModal
        isOpen={isTargetModalOpen}
        onClose={() => setIsTargetModalOpen(false)}
        currentTarget={weeklyTarget}
        onSaveTarget={handleSaveTarget}
      />

      {/* Clean Footer */}
      <footer className="border-t border-slate-200 dark:border-slate-800/80 bg-white/50 dark:bg-slate-900/50 py-6 text-center text-xs text-slate-500 dark:text-slate-400 mt-12">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Leaf className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span className="font-semibold text-slate-800 dark:text-slate-200">EcoTrack</span>
            <span>— Personal Carbon Footprint Tracker</span>
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <span>Car (0.20 kg/km)</span>
            <span>Bus (0.08 kg/km)</span>
            <span>Grid (0.80 kg/kWh)</span>
            <span>Meals (0.5–2.0 kg)</span>
          </div>
          <div className="flex items-center gap-1 text-[11px] text-slate-400">
            <span>Climate-conscious daily living</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
